#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int a, char** args) {
    char * file = "fakefile";
   
    int b;
    if(( b = fork()) == 0){
        printf("I am child %d\n",getpid());
        
         printf("after exec\n");
        
    }else{
        printf("%s %d\n",file,getpid());
    }
}